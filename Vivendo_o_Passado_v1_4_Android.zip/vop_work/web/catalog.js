/* Catálogo aberto: pesquisa de metadados no Internet Archive.
   A licença informada é declarada pelo próprio depositante; confira sempre a página da obra. */
(()=>{
 const grid=document.getElementById('openCatalogGrid');
 const status=document.getElementById('openCatalogStatus');
 if(!grid||!status)return;
 const tabs=[...document.querySelectorAll('.catalog-tab')];
 const searches={
  all:'(title:(classic film) OR title:(silent film) OR title:(public domain))',
  movie:'(title:(film) OR title:(movie) OR subject:(motion pictures))',
  animation:'(subject:(animation) OR subject:(cartoons) OR title:(animated))',
  series:'(mediatype:movies AND (subject:(television) OR title:(television) OR title:(tv)))',
  anime:'(subject:(anime) OR title:(anime) OR subject:(japanese animation))'
 };
 let current='all', cache={};
 const license='(licenseurl:http*publicdomain* OR licenseurl:http*creativecommons.org/publicdomain* OR licenseurl:http*creativecommons.org/licenses/by/4.0* OR licenseurl:http*creativecommons.org/licenses/by-sa/4.0*)';
 function safeText(v){return String(v||'').replace(/\s+/g,' ').trim()}
 function itemUrl(id){return 'https://archive.org/details/'+encodeURIComponent(id)}
 function posterUrl(id){return 'https://archive.org/services/img/'+encodeURIComponent(id)}
 function render(list){grid.replaceChildren();if(!list.length){status.textContent='Nenhum título encontrado nesta categoria agora. Tente outra categoria ou atualize mais tarde.';return}
  status.textContent=`${list.length} títulos encontrados. Toque em um cartaz para ver a página, a licença e as opções disponíveis.`;
  list.forEach(item=>{const card=document.createElement('article');card.className='open-card';card.tabIndex=0;card.setAttribute('role','link');card.setAttribute('aria-label','Abrir '+item.title+' no Internet Archive');
   const poster=document.createElement('div');poster.className='open-poster';poster.textContent='▶';const img=document.createElement('img');img.loading='lazy';img.alt='';img.src=posterUrl(item.identifier);img.onerror=()=>img.remove();poster.append(img);
   const info=document.createElement('div');info.className='open-card-info';const title=document.createElement('b');title.textContent=safeText(item.title)||'Título sem nome';const small=document.createElement('small');small.textContent=[item.year||'',item.licenseurl?.includes('publicdomain')?'Domínio público':'Licença aberta'].filter(Boolean).join(' · ');info.append(title,small);card.append(poster,info);
   const open=()=>window.open(itemUrl(item.identifier),'_blank','noopener');card.addEventListener('click',open);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open()}});grid.append(card);
  });
 }
 async function load(category,force=false){current=category;tabs.forEach(t=>t.classList.toggle('active',t.dataset.openCategory===category));if(cache[category]&&!force){render(cache[category]);return}
  grid.replaceChildren();status.textContent='Buscando títulos e verificando os dados de licença…';
  const q=`mediatype:movies AND ${license} AND ${searches[category]}`;
  const params=new URLSearchParams({q,fl:'identifier,title,year,licenseurl',rows:'24',page:'1',output:'json',sort:'downloads desc'});
  try{const response=await fetch('https://archive.org/advancedsearch.php?'+params.toString(),{headers:{'Accept':'application/json'}});if(!response.ok)throw new Error('HTTP '+response.status);const data=await response.json();const docs=(data.response?.docs||[]).filter(x=>x.identifier&&x.licenseurl);cache[category]=docs;render(docs)}
  catch(err){console.warn('Catálogo aberto indisponível',err);status.textContent='Não foi possível carregar o catálogo agora. Verifique sua conexão e tente novamente.';const link=document.createElement('a');link.href='https://archive.org/details/movies';link.target='_blank';link.rel='noopener';link.className='text-button';link.textContent='Abrir catálogo do Internet Archive';grid.append(link)}
 }
 tabs.forEach(t=>t.addEventListener('click',()=>load(t.dataset.openCategory)));
 document.getElementById('refreshOpenCatalog')?.addEventListener('click',()=>load(current,true));
 load('all');
})();
