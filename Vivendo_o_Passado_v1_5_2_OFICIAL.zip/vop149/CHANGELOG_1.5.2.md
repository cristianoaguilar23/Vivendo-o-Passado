# Vivendo o Passado 1.5.2

## Correções de compilação e identificação
- Corrigida a identificação da versão do projeto para 1.5.2.
- Incrementado o versionCode Android para 20.
- Mantida a correção de acesso à hierarquia de Views na MainActivity.
- Mantidos o catálogo e a fileira de animações nostálgicas da versão 1.5.1.
- Removido do pacote o workflow antigo que não deve ser restaurado durante a compilação.

Esta versão não adiciona catálogo de filmes licenciados nem garante disponibilidade de reprodução dos títulos; os cartões existentes continuam sendo entradas de consulta.
